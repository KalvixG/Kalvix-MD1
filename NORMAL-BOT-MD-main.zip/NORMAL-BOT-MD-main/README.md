<img src="https://i.imgur.com/dBaSKWF.gif" height="90" width="100%">

## 💯𝐏𝐎𝐏𝐊𝐈𝐃 𝐌𝐃❤️

[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&size=30&pause=1000&color=0000FF&center=true&vCenter=true&width=815&height=60&lines=▇+▇+▇+▇+▇+▇+▇)](https://git.io/typing-svg) 




[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&size=30&pause=1000&color=0000FF&center=true&vCenter=true&width=815&height=60&lines=𝐏𝐎𝐏𝐊𝐈𝐃+𝐌𝐃+⭕+𝐂𝐑𝐄𝐀𝐓𝐄𝐃+𝐁𝐘+𝐏𝐎𝐏𝐊𝐈𝐃)](https://git.io/typing-svg) 

<p align="centre"><img src="https://i.ibb.co/KG7GSN5/23a53bc84ebf86fae0c17074810e3307.jpg"500" height="600" />




<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>


<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

## 𝐇𝐎𝐖 𝐓𝐎 𝐏𝐀𝐈𝐑 𝐏𝐎𝐏𝐊𝐈𝐃 𝐌𝐃


<p align="center">
<a href="https://github.com/Popkiddevs/followers"><img title="Followers" src="https://img.shields.io/github/followers/Popkiddevs?color=blue&style=flat-square"></a>
<a href="https://github.com/Popkiddevs/NORMAL-BOT-MD/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/Popkiddevs/NORMAL-BOT-MD?color=blue&style=flat-square"></a>
<a href="https://github.com/Popkiddevs/NORMAL-BOT-MD/network/members"><img title="Forks" src="https://img.shields.io/github/forks/Popkiddevs/NORMAL-BOT-MD?color=blue&style=flat-square"></a>
<a href="https://github.com/Popkiddevs/NORMAL-BOT-MD/"><img title="Size" src="https://img.shields.io/github/repo-size/Popkiddevs/NORMAL-BOT-MD?style=flat-square&color=blue"></a>
<a href="https://github.com/Popkiddevs/NORMAL-BOT-MD/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained%3F-yes-green.svg"></a>&nbsp;&nbsp;
</p>
<p align='center'>
</p>

 <p align="center"><img src="https://profile-counter.glitch.me/{POPKID-MD}/count.svg" alt="Popkid :: Visitor's Count" old_src="https://profile-counter.glitch.me/{enzo}/count.svg" /></p>






## HOW TO GET POPKID BOT

  
[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&color=blue&lines=𝗙𝗢𝗥𝗞+𝗔𝗡𝗗+𝗦𝗧𝗔𝗥+𝗥𝗘𝗣𝗢)](https://git.io/typing-svg)
 

  
   
   <a href="https://github.com/Popkiddevs/NORMAL-BOT-MD/fork"><img title="FORK-REPO" src="https://img.shields.io/badge/FORK-REPO-h?color=blue&style=for-the-badge&logo=tesla" width="297" height="40.45"/></a></p>


<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

 
 
[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&color=blue&lines=𝗦𝗘𝗦𝗦𝗜𝗢𝗡+𝗜𝗗+𝗦𝗜𝗧𝗘+𝗜𝗦+𝗛𝗘𝗥𝗘)](https://git.io/typing-svg)
 


  <a href="https://popkid-sessions-generator-1iqg.onrender.com/pair"><img title="GET-SESSION ID HERE" src="https://img.shields.io/badge/GET-SESSION ID HERE-h?color=green&style=for-the-badge&logo=nike" width="230" height="38.45"/></a></p>

  
  <a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&color=blue&lines=𝐃𝐄𝐏𝐋𝐎𝐘+𝐎𝐍+𝐇𝐄𝐑𝐎𝐊𝐔)](https://git.io/typing-svg)


 
  

 
## 𝐅𝐎𝐑 𝐎𝐍𝐄-𝐓𝐀𝐏 𝐃𝐄𝐏𝐋𝐎𝐘𝐌𝐄𝐍𝐓 𝐔𝐒𝐄 𝐓𝐇𝐈𝐒 𝐁𝐔𝐓𝐓𝐎𝐍

   🕳IF YOU DON'T HAVE A HEROKU ACCOUNT...CREATE ONE
   
   <a href="https://signup.heroku.com/"><img title="CREATE-ACCOUNT" src="https://img.shields.io/badge/CREATE-ACCOUNT-h?color=purple&style=for-the-badge&logo=heroku" width="180" height="43.45"/></a></p>

   ☢️IF YOU ALREADY HAVE A HEROKU ACCOUNT...DEPLOY NOW

 <a href="https://dashboard.heroku.com/new?template=https://github.com/Popkiddevs/NORMAL-BOT-MD"><img title="DEPLOY-ON HEROKU" src="https://img.shields.io/badge/DEPLOY-ON HEROKU-h?color=purple&style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>

 
 [![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&size=30&pause=1000&color=0000FF&center=true&vCenter=true&width=815&height=60&lines=▭+▬+▭+▬+▭+▬+▭+▬+▭+▬+▭)](https://git.io/typing-svg) 

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

## FINAL REMARKS ON MY REPO (STATS)

![ Stats](https://github-readme-stats.vercel.app/api/pin/?username=Popkiddevs&repo=NORMAL-BOT-MD&show_owner=true&theme=dark)









<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

## CONTACT POPKID HERE
  DM FOR SERIOUS BUSINESS

   <a href="https://github.com/Popkiddevs/NORMAL-BOT-MD-INFO"><img title="CONTACT-POPKID" src="https://img.shields.io/badge/CONTACT-POPKID-h?color=green&style=for-the-badge&logo=tesla" width="240" height="45.45"/></a></p>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

